bl_info = {
    "name": "Panko's Timesaver Plugin",
    "author": "Panko",
    "version": (5, 1, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > ARKit H  |  Helper Scripts",
    "description": "Unified ARKit blendshape management, VRM expression tools, and mesh cleanup utilities",
    "doc_url": "https://github.com/panekopanko/pankosvrmblenderscripts",
    "category": "Rigging",
}

import bpy
from bpy.types import Operator, Panel, PropertyGroup, UIList
from bpy.props import StringProperty, CollectionProperty, IntProperty, BoolProperty, PointerProperty, FloatProperty

# ==============================================================================
#  CONSTANTS
# ==============================================================================

ARKIT_DEFAULTS = {
    "Brows": [
        "browDown", "browDownLeft", "browDownRight",
        "browInnerUp", "browOuterUp", "browOuterUpLeft", "browOuterUpRight",
    ],
    "Eyes": [
        "eyeBlink", "eyeBlinkLeft", "eyeBlinkRight",
        "eyeLookDown", "eyeLookDownLeft", "eyeLookDownRight",
        "eyeLookIn", "eyeLookInLeft", "eyeLookInRight",
        "eyeLookOut", "eyeLookOutLeft", "eyeLookOutRight",
        "eyeLookUp", "eyeLookUpLeft", "eyeLookUpRight",
        "eyeSquint", "eyeSquintLeft", "eyeSquintRight",
        "eyeWide", "eyeWideLeft", "eyeWideRight",
    ],
    "Cheeks": ["cheekPuff", "cheekSquint", "cheekSquintLeft", "cheekSquintRight"],
    "Jaw":    ["jawForward", "jawLeft", "jawRight", "jawOpen"],
    "Mouth": [
        "mouthClose", "mouthFunnel", "mouthPucker", "mouthLeft", "mouthRight",
        "mouthSmile", "mouthSmileLeft", "mouthSmileRight",
        "mouthFrown", "mouthFrownLeft", "mouthFrownRight",
        "mouthDimple", "mouthDimpleLeft", "mouthDimpleRight",
        "mouthStretch", "mouthStretchLeft", "mouthStretchRight",
        "mouthRollLower", "mouthRollUpper", "mouthShrugLower", "mouthShrugUpper",
        "mouthPress", "mouthPressLeft", "mouthPressRight",
        "mouthLowerDown", "mouthLowerDownLeft", "mouthLowerDownRight",
        "mouthUpperUp", "mouthUpperUpLeft", "mouthUpperUpRight",
        "tongueOut",
    ],
    "Nose":  ["noseSneer", "noseSneerRight", "noseSneerLeft"],
    "Other": [],
}

VRM_DEFAULTS = {
    "Emotions": ["happy", "angry", "sad", "relaxed", "surprised", "neutral"],
    "Visemes":  ["aa", "ih", "ou", "ee", "oh"],
    "Blink":    ["blink", "blinkLeft", "blinkRight"],
    "Look":     ["lookUp", "lookDown", "lookLeft", "lookRight"],
}

# Flat ARKit list used by VRM tools
ARKIT_BLENDSHAPES = [s for cat in ARKIT_DEFAULTS.values() for s in cat if cat]
# Remove duplicates introduced by the "Other" empty list while preserving order
_seen = set()
ARKIT_BLENDSHAPES = [s for s in ARKIT_BLENDSHAPES if not (s in _seen or _seen.add(s))]

ARKIT_VRM_BLENDSHAPES = (
    [s for cat in VRM_DEFAULTS.values() for s in cat]
    + ARKIT_BLENDSHAPES
)


# ==============================================================================
#  SHARED UTILITIES
# ==============================================================================

def get_vrm_armature_and_extension():
    """Return (armature_data, armature_obj, vrm_extension) or (None, None, None).
    Searches all armature objects for one with a VRM 1.0 extension — does not
    rely on the armature being named 'Armature'."""
    for obj in bpy.data.objects:
        if obj.type != 'ARMATURE':
            continue
        arm = obj.data
        if not hasattr(arm, "vrm_addon_extension"):
            continue
        ext = arm.vrm_addon_extension
        if not hasattr(ext, "vrm1"):
            continue
        return arm, obj, ext
    return None, None, None


def sync_all_active_indices(context, shape_name):
    """Move the active-shape-key highlight on the Driver and all Target meshes."""
    scene = context.scene
    objs = [t.obj for t in scene.ak_targets if t.obj]
    if scene.ak_driver_mesh:
        objs.append(scene.ak_driver_mesh)
    for o in objs:
        if o and o.type == 'MESH' and o.data.shape_keys:
            idx = o.data.shape_keys.key_blocks.find(shape_name)
            if idx != -1:
                o.active_shape_key_index = idx


def autosort_shapes_logic(context):
    """Sort shapes into ARKit/VRM folders, Corrective_/Jiggle_ by prefix, then Other."""
    scene = context.scene
    master = scene.ak_driver_mesh
    if not master or not master.data.shape_keys:
        return

    kb = master.data.shape_keys.key_blocks
    assigned = set()

    for g in scene.ak_groups:
        g.shapes_csv = ""

    for folder_name, template in ARKIT_DEFAULTS.items():
        group = next((g for g in scene.ak_groups if g.name == folder_name), None)
        if not group:
            group = scene.ak_groups.add()
            group.name = folder_name
        found = [s for s in template if s in kb and s != "Basis"]
        assigned.update(found)
        group.shapes_csv = ",".join(found)

    for folder_name, template in VRM_DEFAULTS.items():
        found = [s for s in template if s in kb and s != "Basis"]
        assigned.update(found)
        if found:
            group = next((g for g in scene.ak_groups if g.name == folder_name), None)
            if not group:
                group = scene.ak_groups.add()
                group.name = folder_name
            group.shapes_csv = ",".join(found)
        else:
            idx = scene.ak_groups.find(folder_name)
            if idx != -1:
                scene.ak_groups.remove(idx)

    all_names = [k.name for k in kb if k.name != "Basis"]
    for prefix, folder_name in [("EXP_", "Expressions"), ("Corrective_", "Corrective"), ("Jiggle_", "Jiggle")]:
        prefix_shapes = sorted(s for s in all_names if s.startswith(prefix) and s not in assigned)
        assigned.update(prefix_shapes)
        if prefix_shapes:
            group = next((g for g in scene.ak_groups if g.name == folder_name), None)
            if not group:
                group = scene.ak_groups.add()
                group.name = folder_name
            group.shapes_csv = ",".join(prefix_shapes)
        else:
            idx = scene.ak_groups.find(folder_name)
            if idx != -1:
                scene.ak_groups.remove(idx)

    other_group = next((g for g in scene.ak_groups if g.name == "Other"), None)
    if not other_group:
        other_group = scene.ak_groups.add()
        other_group.name = "Other"
    other_group.shapes_csv = ",".join(
        sorted(k.name for k in kb if k.name != "Basis" and k.name not in assigned)
    )

    for fname in ["Corrective", "Jiggle", "Other"]:
        idx = scene.ak_groups.find(fname)
        if idx != -1:
            scene.ak_groups.move(idx, len(scene.ak_groups) - 1)


# ==============================================================================
#  DATA MODELS  (Angelus)
# ==============================================================================

class AK_GroupItem(PropertyGroup):
    name:       bpy.props.StringProperty(name="Group Name")
    is_expanded: BoolProperty(name="Expanded", default=True)
    shapes_csv: StringProperty(name="Shapes", default="")


class AK_Target(PropertyGroup):
    obj: PointerProperty(type=bpy.types.Object)


# ==============================================================================
#  OPERATORS — ANGELUS ARKIT HELPER  (prefix: AK_OT_)
# ==============================================================================

class AK_OT_select_shape_key(Operator):
    bl_idname = "ak.select_shape_key"
    bl_label  = "Select Blendshape"
    bl_description = "Select this blendshape on the driver and all driven meshes"
    shape_name: StringProperty()

    def execute(self, context):
        sync_all_active_indices(context, self.shape_name)
        return {'FINISHED'}


class AK_OT_add_arkit_shapes(Operator):
    bl_idname   = "ak.add_arkit_shapes"
    bl_label    = "Add ARKit Shapes (Batch)"
    bl_description = "Add all ARKit blendshapes to the Driver mesh"
    bl_options  = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target = context.scene.ak_driver_mesh
        if not target:
            self.report({'WARNING'}, "Assign a Driver mesh first.")
            return {'CANCELLED'}
        if not target.data.shape_keys:
            target.shape_key_add(name="Basis")
        kb = target.data.shape_keys.key_blocks
        for s in [s for cat in ARKIT_DEFAULTS.values() for s in cat]:
            if s not in kb:
                target.shape_key_add(name=s)
            kb[s].value = 0.0
        autosort_shapes_logic(context)
        return {'FINISHED'}


class AK_OT_add_vrm_shapes(Operator):
    bl_idname   = "ak.add_vrm_shapes"
    bl_label    = "Add VRM Shapes (Batch)"
    bl_description = "Add all VRM blendshapes (Emotions, Visemes, Blink, Look) to the Driver mesh"
    bl_options  = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target = context.scene.ak_driver_mesh
        if not target:
            self.report({'WARNING'}, "Assign a Driver mesh first.")
            return {'CANCELLED'}
        if not target.data.shape_keys:
            target.shape_key_add(name="Basis")
        kb = target.data.shape_keys.key_blocks
        for s in [s for cat in VRM_DEFAULTS.values() for s in cat]:
            if s not in kb:
                target.shape_key_add(name=s)
            kb[s].value = 0.0
        autosort_shapes_logic(context)
        return {'FINISHED'}


class AK_OT_autosort_shapes(Operator):
    bl_idname   = "ak.autosort_shapes"
    bl_label    = "Autosort Shapes"
    bl_description = "Sort shapes into ARKit/VRM folders, then extras to Other"
    bl_options  = {'REGISTER', 'UNDO'}

    def execute(self, context):
        autosort_shapes_logic(context)
        return {'FINISHED'}


class AK_OT_mirror_blendshape(Operator):
    bl_idname   = "ak.mirror_blendshape"
    bl_label    = "Split Left/Right"
    bl_description = "Split the shape based on X axis across Driver and all Driven meshes"
    bl_options  = {'REGISTER', 'UNDO'}
    shape_name: StringProperty()

    def execute(self, context):
        scene = context.scene
        objs = [t.obj for t in scene.ak_targets if t.obj]
        driver_obj = scene.ak_driver_mesh
        if driver_obj:
            objs.append(driver_obj)
        if not objs:
            return {'CANCELLED'}

        left_name  = self.shape_name + "Left"
        right_name = self.shape_name + "Right"

        for obj in objs:
            if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
                continue
            kb = obj.data.shape_keys.key_blocks
            target_shape = kb.get(self.shape_name)
            basis = kb.get("Basis")
            if not target_shape or not basis:
                continue
            for n in (left_name, right_name):
                if n in kb:
                    obj.shape_key_remove(kb[n])
            left_shape  = obj.shape_key_add(name=left_name,  from_mix=False)
            right_shape = obj.shape_key_add(name=right_name, from_mix=False)
            for i, v in enumerate(obj.data.vertices):
                b_co = basis.data[i].co
                s_co = target_shape.data[i].co
                if b_co.x > 0.001:
                    right_shape.data[i].co = s_co
                    left_shape.data[i].co  = b_co
                elif b_co.x < -0.001:
                    left_shape.data[i].co  = s_co
                    right_shape.data[i].co = b_co
                else:
                    left_shape.data[i].co  = b_co
                    right_shape.data[i].co = b_co

        if driver_obj and driver_obj.data.shape_keys:
            for t in scene.ak_targets:
                tar = t.obj
                if not tar or not tar.data.shape_keys:
                    continue
                for n in (left_name, right_name):
                    t_kb = tar.data.shape_keys.key_blocks.get(n)
                    if t_kb:
                        t_kb.driver_remove("value")
                        drv = t_kb.driver_add("value").driver
                        drv.type = 'SUM'
                        var = drv.variables.new()
                        var.name = "src_val"
                        var.type = 'SINGLE_PROP'
                        var.targets[0].id_type = 'OBJECT'
                        var.targets[0].id = driver_obj
                        var.targets[0].data_path = f'data.shape_keys.key_blocks["{n}"].value'

        autosort_shapes_logic(context)
        self.report({'INFO'}, f"Split '{self.shape_name}' → {left_name} / {right_name}")
        return {'FINISHED'}


class AK_OT_select_all_meshes(Operator):
    bl_idname   = "ak.select_all_meshes"
    bl_label    = "Select All Rig Meshes"
    bl_description = "Select the Driver and all Target meshes in the viewport"
    bl_options  = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        scene = context.scene
        objs = [t.obj for t in scene.ak_targets if t.obj]
        if scene.ak_driver_mesh:
            objs.append(scene.ak_driver_mesh)
            context.view_layer.objects.active = scene.ak_driver_mesh
        for o in objs:
            o.select_set(True)
        return {'FINISHED'}


class AK_OT_create_drivers(Operator):
    bl_idname   = "ak.create_drivers"
    bl_label    = "Link Meshes"
    bl_description = "Create drivers on secondary meshes controlled by the Driver mesh blendshapes"

    def execute(self, context):
        scene = context.scene
        src = scene.ak_driver_mesh
        if not src or not src.data.shape_keys:
            return {'CANCELLED'}
        for item in scene.ak_targets:
            tar = item.obj
            if not tar or tar == src:
                continue
            if not tar.data.shape_keys:
                tar.shape_key_add(name="Basis")
            for key in src.data.shape_keys.key_blocks:
                t_kb = tar.data.shape_keys.key_blocks.get(key.name)
                if not t_kb:
                    continue
                t_kb.driver_remove("value")
                drv = t_kb.driver_add("value").driver
                drv.type = 'SUM'
                var = drv.variables.new()
                var.name = "src_val"
                var.type = 'SINGLE_PROP'
                var.targets[0].id_type = 'KEY'
                var.targets[0].id = src.data.shape_keys
                var.targets[0].data_path = f'key_blocks["{key.name}"].value'
        return {'FINISHED'}


class AK_OT_remove_drivers(Operator):
    bl_idname   = "ak.remove_drivers"
    bl_label    = "Unlink Meshes"
    bl_description = "Remove driver setup from all Target mesh blendshapes"

    def execute(self, context):
        for item in context.scene.ak_targets:
            tar = item.obj
            if not tar or not tar.data.shape_keys:
                continue
            for kb in tar.data.shape_keys.key_blocks:
                kb.driver_remove("value")
        return {'FINISHED'}


class AK_OT_select_basis(Operator):
    bl_idname   = "ak.select_basis"
    bl_label    = "Select Basis"
    bl_description = "Set the active shape key to Basis on all meshes"

    def execute(self, context):
        scene = context.scene
        objs = [t.obj for t in scene.ak_targets if t.obj]
        if scene.ak_driver_mesh:
            objs.append(scene.ak_driver_mesh)
        for o in objs:
            if o.data.shape_keys:
                o.active_shape_key_index = 0
        return {'FINISHED'}


class AK_OT_global_zero(Operator):
    bl_idname   = "ak.global_zero"
    bl_label    = "Zero Everything"
    bl_description = "Set all blendshape values to 0 across Driver and all Target meshes"

    def execute(self, context):
        scene = context.scene
        objs = [t.obj for t in scene.ak_targets if t.obj]
        if scene.ak_driver_mesh:
            objs.append(scene.ak_driver_mesh)
        for o in objs:
            if o.data.shape_keys:
                for kb in o.data.shape_keys.key_blocks:
                    kb.value = 0.0
        return {'FINISHED'}


class AK_OT_delete_all_shapes(Operator):
    bl_idname   = "ak.delete_all_shapes"
    bl_label    = "Delete All Shapes"
    bl_description = "Delete ALL blendshapes on all meshes and clear folders. Cannot be undone easily."
    bl_options  = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.ak_driver_mesh
        if obj and obj.data.shape_keys:
            obj.shape_key_clear()
        for t in context.scene.ak_targets:
            if t.obj and t.obj.data.shape_keys:
                t.obj.shape_key_clear()
        context.scene.ak_groups.clear()
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class AK_OT_target_add_selected(Operator):
    bl_idname   = "ak.target_add_selected"
    bl_label    = "Add Selected"
    bl_description = "Add currently selected mesh(es) to the Target list"
    bl_options  = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for o in context.selected_objects:
            if o.type == 'MESH' and o != context.scene.ak_driver_mesh:
                if not any(t.obj == o for t in context.scene.ak_targets):
                    context.scene.ak_targets.add().obj = o
        return {'FINISHED'}


class AK_OT_target_remove(Operator):
    bl_idname   = "ak.target_remove"
    bl_label    = "Remove"
    bl_description = "Remove the highlighted mesh from the Target list"
    bl_options  = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.scene.ak_target_index >= 0:
            context.scene.ak_targets.remove(context.scene.ak_target_index)
        return {'FINISHED'}


class AK_OT_groups_toggle(Operator):
    bl_idname = "ak.groups_toggle"
    bl_label  = "Toggle All"

    def execute(self, context):
        state = not any(g.is_expanded for g in context.scene.ak_groups)
        for g in context.scene.ak_groups:
            g.is_expanded = state
        return {'FINISHED'}


class AK_OT_delete_single_shape(Operator):
    bl_idname   = "ak.delete_single_shape"
    bl_label    = "Delete Blendshape?"
    bl_description = "Delete this blendshape from all meshes"
    bl_options  = {'REGISTER', 'UNDO'}
    shape_name: StringProperty()

    def execute(self, context):
        scene = context.scene
        for t in scene.ak_targets:
            tar = t.obj
            if tar and tar.data.shape_keys:
                kb = tar.data.shape_keys.key_blocks.get(self.shape_name)
                if kb:
                    kb.driver_remove("value")
                    tar.shape_key_remove(kb)
        master = scene.ak_driver_mesh
        if master and master.data.shape_keys:
            kb = master.data.shape_keys.key_blocks.get(self.shape_name)
            if kb:
                master.shape_key_remove(kb)
        autosort_shapes_logic(context)
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class AK_OT_add_single_arkit_shape(Operator):
    bl_idname   = "ak.add_single_arkit_shape"
    bl_label    = "Add Shapekey"
    bl_description = "Add this shape key to all Target meshes and create drivers"
    bl_options  = {'REGISTER', 'UNDO'}
    shape_name: StringProperty()

    def execute(self, context):
        scene = context.scene
        targets = [t.obj for t in scene.ak_targets if t.obj]
        if not targets:
            self.report({'WARNING'}, "Assign Driver/Target meshes first.")
            return {'CANCELLED'}
        for ob in targets:
            if ob.type != 'MESH':
                continue
            if not ob.data.shape_keys:
                ob.shape_key_add(name="Basis")
            kb = ob.data.shape_keys.key_blocks
            if self.shape_name not in kb:
                ob.shape_key_add(name=self.shape_name)
            kb[self.shape_name].value = 0.0
            t_kb = kb.get(self.shape_name)
            t_kb.driver_remove("value")
            drv = t_kb.driver_add("value").driver
            drv.type = 'SUM'
            var = drv.variables.new()
            var.name = "src_val"
            var.type = 'SINGLE_PROP'
            var.targets[0].id_type = 'OBJECT'
            var.targets[0].id = scene.ak_driver_mesh
            var.targets[0].data_path = f'data.shape_keys.key_blocks["{self.shape_name}"].value'
        autosort_shapes_logic(context)
        return {'FINISHED'}


# ==============================================================================
#  OPERATORS — VRM TOOLS  (prefix: PANKO_OT_)
# ==============================================================================

class PANKO_OT_CreateARKitBlendshapes(Operator):
    """Create all 52 ARKit blendshapes on the active mesh"""
    bl_idname  = "panko.create_arkit_blendshapes"
    bl_label   = "Create ARKit Blendshapes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        if obj.data.shape_keys is None:
            obj.shape_key_add(name="Basis", from_mix=False)
        created = skipped = 0
        for name in ARKIT_BLENDSHAPES:
            if obj.data.shape_keys.key_blocks.get(name):
                skipped += 1
            else:
                obj.shape_key_add(name=name, from_mix=False)
                created += 1
        self.report({'INFO'}, f"Created {created} ARKit blendshapes, skipped {skipped}")
        return {'FINISHED'}


class PANKO_OT_CreateARKitVRMBlendshapes(Operator):
    """Create ARKit + VRM blendshapes on the active mesh"""
    bl_idname  = "panko.create_arkit_vrm_blendshapes"
    bl_label   = "Create ARKit + VRM Blendshapes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        if obj.data.shape_keys is None:
            obj.shape_key_add(name="Basis", from_mix=False)
        created = skipped = 0
        for name in ARKIT_VRM_BLENDSHAPES:
            if obj.data.shape_keys.key_blocks.get(name):
                skipped += 1
            else:
                obj.shape_key_add(name=name, from_mix=False)
                created += 1
        self.report({'INFO'}, f"Created {created} blendshapes, skipped {skipped}")
        return {'FINISHED'}


class PANKO_OT_AddARKitToVRMExpressions(Operator):
    """Add all ARKit blendshapes as VRM 1.0 custom expressions"""
    bl_idname  = "panko.add_arkit_to_vrm"
    bl_label   = "Add ARKit to VRM Expressions"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        arm, _, _ = get_vrm_armature_and_extension()
        return arm is not None and any(
            o.type == 'MESH' and o.data.shape_keys for o in bpy.data.objects
        )

    def execute(self, context):
        armature, armature_obj, vrm_extension = get_vrm_armature_and_extension()
        if not armature:
            self.report({'ERROR'}, "VRM armature not found!")
            return {'CANCELLED'}

        mesh_obj = next(
            (o for o in bpy.data.objects if o.type == 'MESH' and o.data.shape_keys), None
        )
        if not mesh_obj:
            self.report({'ERROR'}, "No mesh with shape keys found!")
            return {'CANCELLED'}

        expressions = vrm_extension.vrm1.expressions
        shape_keys  = mesh_obj.data.shape_keys.key_blocks
        created = skipped = 0

        for name in ARKIT_BLENDSHAPES:
            if name not in shape_keys:
                skipped += 1
                continue
            if any(c.custom_name == name for c in expressions.custom):
                skipped += 1
                continue
            new_custom = expressions.custom.add()
            new_custom.custom_name = name
            new_bind = new_custom.morph_target_binds.add()
            new_bind.node.mesh_object_name = mesh_obj.name
            new_bind.index  = name
            new_bind.weight = 1.0
            created += 1

        self.report({'INFO'}, f"Created {created} VRM expressions, skipped {skipped}")
        return {'FINISHED'}


class PANKO_OT_AssignBlendshapesToProxies(Operator):
    """Assign all ARKit shape keys to their VRM custom expressions"""
    bl_idname  = "panko.assign_blendshapes_proxies"
    bl_label   = "Assign All Meshes to Proxies"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        arm, arm_obj, _ = get_vrm_armature_and_extension()
        return arm is not None and arm_obj is not None and any(
            o.type == 'MESH' and o.data.shape_keys for o in bpy.data.objects
        )

    def execute(self, context):
        armature, armature_obj, vrm_extension = get_vrm_armature_and_extension()
        if not armature or not armature_obj:
            self.report({'ERROR'}, "VRM armature not found!")
            return {'CANCELLED'}

        mesh_obj = next(
            (o for o in bpy.data.objects if o.type == 'MESH' and o.data.shape_keys), None
        )
        if not mesh_obj:
            self.report({'ERROR'}, "No mesh with shape keys found!")
            return {'CANCELLED'}

        expressions = vrm_extension.vrm1.expressions
        shape_keys  = mesh_obj.data.shape_keys.key_blocks
        assigned = skipped = 0

        for name in ARKIT_BLENDSHAPES:
            if name not in shape_keys:
                skipped += 1
                continue
            expr = next((e for e in expressions.custom if e.custom_name == name), None)
            if not expr:
                skipped += 1
                continue
            if len(expr.morph_target_binds) > 0 and expr.morph_target_binds[0].index == name:
                skipped += 1
                continue
            try:
                bpy.ops.vrm.add_vrm1_expression_morph_target_bind(
                    armature_object_name=armature_obj.name,
                    expression_name=name,
                )
                if expr.morph_target_binds:
                    bind = expr.morph_target_binds[-1]
                    bind.node.bpy_object = mesh_obj
                    bind.index = name
                    assigned += 1
                else:
                    skipped += 1
            except Exception:
                skipped += 1

        self.report({'INFO'}, f"Assigned {assigned} binds, skipped {skipped}")
        return {'FINISHED'}


class PANKO_OT_AssignSelectedMeshBlendshapesToProxies(Operator):
    """Assign ARKit shape keys from the active mesh to matching VRM expressions"""
    bl_idname  = "panko.assign_selected_mesh_proxies"
    bl_label   = "Assign Selected Mesh to Proxies"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        arm, arm_obj, _ = get_vrm_armature_and_extension()
        obj = context.active_object
        return (arm is not None and arm_obj is not None
                and obj is not None and obj.type == 'MESH'
                and obj.data.shape_keys is not None)

    def execute(self, context):
        mesh_obj   = context.active_object
        shape_keys = mesh_obj.data.shape_keys.key_blocks
        armature, armature_obj, vrm_ext = get_vrm_armature_and_extension()
        if not armature or not armature_obj:
            self.report({'ERROR'}, "VRM armature not found!")
            return {'CANCELLED'}

        expressions = vrm_ext.vrm1.expressions
        assigned = skipped = 0

        for name in ARKIT_BLENDSHAPES:
            if name not in shape_keys:
                skipped += 1
                continue
            expr = next((e for e in expressions.custom if e.custom_name == name), None)
            if not expr:
                skipped += 1
                continue
            if any(b.node.bpy_object == mesh_obj and b.index == name
                   for b in expr.morph_target_binds):
                skipped += 1
                continue
            try:
                bpy.ops.vrm.add_vrm1_expression_morph_target_bind(
                    armature_object_name=armature_obj.name,
                    expression_name=name,
                )
                bind = expr.morph_target_binds[-1]
                bind.node.bpy_object = mesh_obj
                bind.index = name
                assigned += 1
            except Exception:
                skipped += 1

        self.report({'INFO'}, f"Assigned {assigned} from selected mesh, skipped {skipped}")
        return {'FINISHED'}


class PANKO_OT_AddCustomBlendshape(Operator):
    """Add a single custom blendshape to the active mesh"""
    bl_idname  = "panko.add_custom_blendshape"
    bl_label   = "Add Custom Blendshape"
    bl_options = {'REGISTER', 'UNDO'}

    shape_name: StringProperty(name="Shape Name", default="custom_expression")

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "shape_name")

    def execute(self, context):
        obj = context.active_object
        name = self.shape_name.strip()
        if not name:
            self.report({'ERROR'}, "Shape name cannot be empty!")
            return {'CANCELLED'}
        if obj.data.shape_keys is None:
            obj.shape_key_add(name="Basis", from_mix=False)
        if obj.data.shape_keys.key_blocks.get(name):
            self.report({'WARNING'}, f"'{name}' already exists!")
            return {'CANCELLED'}
        obj.shape_key_add(name=name, from_mix=False)
        self.report({'INFO'}, f"Created '{name}'")
        return {'FINISHED'}


class PANKO_OT_AddMultipleCustomBlendshapes(Operator):
    """Add multiple custom blendshapes at once (comma-separated)"""
    bl_idname  = "panko.add_multiple_custom_blendshapes"
    bl_label   = "Add Multiple Blendshapes"
    bl_options = {'REGISTER', 'UNDO'}

    shape_names: StringProperty(name="Shape Names", default="")

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Comma-separated names:")
        layout.prop(self, "shape_names", text="")
        layout.label(text="e.g.  smirk, wink, pout", icon='INFO')

    def execute(self, context):
        obj = context.active_object
        names = [n.strip() for n in self.shape_names.split(',') if n.strip()]
        if not names:
            self.report({'ERROR'}, "No valid names provided!")
            return {'CANCELLED'}
        if obj.data.shape_keys is None:
            obj.shape_key_add(name="Basis", from_mix=False)
        created = skipped = 0
        for name in names:
            if obj.data.shape_keys.key_blocks.get(name):
                skipped += 1
            else:
                obj.shape_key_add(name=name, from_mix=False)
                created += 1
        self.report({'INFO'}, f"Created {created}, skipped {skipped}")
        return {'FINISHED'}


class PANKO_OT_AddCustomBlendshapeToVRM(Operator):
    """Add a custom blendshape to VRM expressions"""
    bl_idname  = "panko.add_custom_blendshape_to_vrm"
    bl_label   = "Add Custom Shape to VRM"
    bl_options = {'REGISTER', 'UNDO'}

    shape_name: StringProperty(name="Shape Key Name", default="")

    @classmethod
    def poll(cls, context):
        arm, _, _ = get_vrm_armature_and_extension()
        obj = context.active_object
        return (arm is not None and obj is not None
                and obj.type == 'MESH' and obj.data.shape_keys is not None)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        layout.label(text="Select shape key to add to VRM:")
        if obj and obj.data.shape_keys:
            layout.prop_search(self, "shape_name", obj.data.shape_keys, "key_blocks", text="Shape Key")
        else:
            layout.prop(self, "shape_name")

    def execute(self, context):
        name = self.shape_name.strip()
        if not name:
            self.report({'ERROR'}, "Shape name cannot be empty!")
            return {'CANCELLED'}
        mesh_obj = context.active_object
        armature, armature_obj, vrm_extension = get_vrm_armature_and_extension()
        if not armature or not armature_obj:
            self.report({'ERROR'}, "VRM armature not found!")
            return {'CANCELLED'}
        expressions = vrm_extension.vrm1.expressions
        shape_keys  = mesh_obj.data.shape_keys.key_blocks
        if name not in shape_keys:
            self.report({'ERROR'}, f"Shape key '{name}' not found!")
            return {'CANCELLED'}
        if any(c.custom_name == name for c in expressions.custom):
            self.report({'WARNING'}, f"VRM expression '{name}' already exists!")
            return {'CANCELLED'}
        new_custom = expressions.custom.add()
        new_custom.custom_name = name
        new_bind = new_custom.morph_target_binds.add()
        new_bind.node.mesh_object_name = mesh_obj.name
        new_bind.index  = str(shape_keys.find(name))
        new_bind.weight = 1.0
        try:
            bpy.ops.vrm.add_vrm1_expression_morph_target_bind(
                armature_object_name=armature_obj.name,
                expression_name=name,
            )
            if new_custom.morph_target_binds:
                bind = new_custom.morph_target_binds[-1]
                bind.node.bpy_object = mesh_obj
                bind.index = name
        except Exception:
            pass
        self.report({'INFO'}, f"Added '{name}' to VRM expressions")
        return {'FINISHED'}


# ==============================================================================
#  OPERATORS — MESH CLEANUP  (prefix: PANKO_OT_)
# ==============================================================================

class PANKO_OT_RemoveEmptyBlendshapes(Operator):
    """Remove shape keys with no vertex deformation from Basis on the active mesh"""
    bl_idname   = "panko.remove_empty_blendshapes"
    bl_label    = "Remove Empty Blendshapes"
    bl_description = "Delete shape keys whose every vertex matches the Basis position"
    bl_options  = {'REGISTER', 'UNDO'}

    threshold: FloatProperty(
        name="Threshold",
        description="Max vertex distance from Basis to be considered empty",
        default=0.0001,
        min=0.0,
        max=0.01,
        precision=5,
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH'
                and obj.data.shape_keys
                and len(obj.data.shape_keys.key_blocks) > 1)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, "threshold")

    def execute(self, context):
        obj   = context.active_object
        kb    = obj.data.shape_keys.key_blocks
        basis = kb.get("Basis")
        if not basis:
            self.report({'WARNING'}, "No Basis shape key found!")
            return {'CANCELLED'}

        to_remove = []
        for key in kb:
            if key.name == "Basis":
                continue
            if all(
                (key.data[i].co - basis.data[i].co).length <= self.threshold
                for i in range(len(obj.data.vertices))
            ):
                to_remove.append(key.name)

        for name in to_remove:
            key = kb.get(name)
            if key:
                obj.shape_key_remove(key)

        self.report({'INFO'}, f"Removed {len(to_remove)} empty blendshapes")
        return {'FINISHED'}


class PANKO_OT_RemoveEmptyVertexGroups(Operator):
    """Remove vertex groups with no vertices assigned on the active mesh"""
    bl_idname   = "panko.remove_empty_vertex_groups"
    bl_label    = "Remove Empty Vertex Groups"
    bl_description = "Delete vertex groups that have no vertices weighted to them"
    bl_options  = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and len(obj.vertex_groups) > 0

    def execute(self, context):
        obj = context.active_object
        used = set()
        for v in obj.data.vertices:
            for g in v.groups:
                if g.weight > 0.0:
                    used.add(g.group)

        to_remove = [vg for i, vg in enumerate(obj.vertex_groups) if i not in used]
        for vg in to_remove:
            obj.vertex_groups.remove(vg)

        self.report({'INFO'}, f"Removed {len(to_remove)} empty vertex groups")
        return {'FINISHED'}


class PANKO_OT_RemoveUnassignedBoneVertexGroups(Operator):
    """Remove vertex groups not linked to any bone in the armature modifier"""
    bl_idname   = "panko.remove_unassigned_bone_vgroups"
    bl_label    = "Remove Unassigned Bone VGroups"
    bl_description = "Delete vertex groups whose name doesn't match any bone in the armature"
    bl_options  = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and len(obj.vertex_groups) > 0

    def execute(self, context):
        obj = context.active_object
        armature = next(
            (m.object for m in obj.modifiers if m.type == 'ARMATURE' and m.object),
            None,
        )
        if not armature:
            self.report({'WARNING'}, "No armature modifier found on this mesh!")
            return {'CANCELLED'}

        bone_names = {b.name for b in armature.data.bones}
        to_remove  = [vg for vg in obj.vertex_groups if vg.name not in bone_names]
        for vg in to_remove:
            obj.vertex_groups.remove(vg)

        self.report({'INFO'}, f"Removed {len(to_remove)} vertex groups not linked to bones")
        return {'FINISHED'}


# ==============================================================================
#  OPERATORS — NAMING & SORTING  (prefix: PANKO_OT_)
# ==============================================================================

class PANKO_OT_RenameLRSuffix(Operator):
    """Rename shape key suffixes from _L / _R / .L / .R to Left / Right"""
    bl_idname   = "panko.rename_lr_suffix"
    bl_label    = "Rename L/R → Left/Right"
    bl_description = "Convert _L, .L, _R, .R shape key suffixes to Left / Right"
    bl_options  = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys

    def execute(self, context):
        obj = context.active_object
        renamed = 0
        for key in obj.data.shape_keys.key_blocks:
            for suffix, replacement in [("_L", "Left"), (".L", "Left"),
                                         ("_R", "Right"), (".R", "Right")]:
                if key.name.endswith(suffix):
                    key.name = key.name[: -len(suffix)] + replacement
                    renamed += 1
                    break
        self.report({'INFO'}, f"Renamed {renamed} shape keys")
        return {'FINISHED'}


class PANKO_OT_SortShapeKeysAlpha(Operator):
    """Sort all shape keys alphabetically, keeping Basis first"""
    bl_idname   = "panko.sort_shape_keys_alpha"
    bl_label    = "Sort Shape Keys A–Z"
    bl_description = "Sort shape keys alphabetically, Basis stays at index 0"
    bl_options  = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH'
                and obj.data.shape_keys
                and len(obj.data.shape_keys.key_blocks) > 2)

    def execute(self, context):
        obj = context.active_object
        kb  = obj.data.shape_keys.key_blocks

        # Collect non-Basis names sorted
        non_basis = sorted(k.name for k in kb if k.name != "Basis")

        # Use move operations to arrange them in order
        for target_idx, name in enumerate(non_basis, start=1):
            current_idx = kb.find(name)
            while current_idx > target_idx:
                obj.active_shape_key_index = current_idx
                bpy.ops.object.shape_key_move(type='UP')
                current_idx -= 1

        self.report({'INFO'}, f"Sorted {len(non_basis)} shape keys alphabetically")
        return {'FINISHED'}


class PANKO_OT_ResetBlendshapes(Operator):
    """Reset all shape key values to 0 on the active mesh"""
    bl_idname   = "panko.reset_blendshapes"
    bl_label    = "Reset Blendshapes to Zero"
    bl_description = "Set all shape key values to 0 on the active mesh"
    bl_options  = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys

    def execute(self, context):
        obj = context.active_object
        reset = 0
        for key in obj.data.shape_keys.key_blocks:
            if key.name != "Basis":
                key.value = 0.0
                reset += 1
        self.report({'INFO'}, f"Reset {reset} shape keys to 0")
        return {'FINISHED'}


class PANKO_OT_FindReplaceShapeKeyNames(Operator):
    """Find & replace text in shape key names"""
    bl_idname   = "panko.find_replace_shape_key_names"
    bl_label    = "Find & Replace Shape Key Names"
    bl_description = "Find and replace text in all shape key names on the active mesh"
    bl_options  = {'REGISTER', 'UNDO'}

    find:    StringProperty(name="Find",    default="")
    replace: StringProperty(name="Replace", default="")

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "find")
        layout.prop(self, "replace")

    def execute(self, context):
        if not self.find:
            self.report({'WARNING'}, "Find text cannot be empty!")
            return {'CANCELLED'}
        obj = context.active_object
        renamed = 0
        for key in obj.data.shape_keys.key_blocks:
            if self.find in key.name:
                key.name = key.name.replace(self.find, self.replace)
                renamed += 1
        self.report({'INFO'}, f"Renamed {renamed} shape keys")
        return {'FINISHED'}


# ==============================================================================
#  OPERATORS — EXP_ PREFIX ASSIGNER  (prefix: PANKO_OT_)
# ==============================================================================

class PANKO_OT_ToggleEXPPrefix(Operator):
    """Toggle the EXP_ prefix on a single shape key"""
    bl_idname   = "panko.toggle_exp_prefix"
    bl_label    = "Toggle EXP_ Prefix"
    bl_description = "Add or remove the EXP_ prefix on this shape key"
    bl_options  = {'REGISTER', 'UNDO'}

    shape_name: StringProperty()

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.data.shape_keys:
            return {'CANCELLED'}
        key = obj.data.shape_keys.key_blocks.get(self.shape_name)
        if not key:
            return {'CANCELLED'}
        if key.name.startswith("EXP_"):
            key.name = key.name[4:]
        else:
            key.name = "EXP_" + key.name
        return {'FINISHED'}


class PANKO_OT_EXPPrefixBatchAdd(Operator):
    """Add EXP_ prefix to all non-Basis shape keys that don't already have it"""
    bl_idname   = "panko.exp_prefix_batch_add"
    bl_label    = "Add EXP_ to All"
    bl_description = "Add EXP_ prefix to every shape key on the active mesh (except Basis)"
    bl_options  = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys

    def execute(self, context):
        obj = context.active_object
        count = 0
        for key in obj.data.shape_keys.key_blocks:
            if key.name == "Basis" or key.name.startswith("EXP_"):
                continue
            key.name = "EXP_" + key.name
            count += 1
        self.report({'INFO'}, f"Added EXP_ to {count} shape keys")
        return {'FINISHED'}


class PANKO_OT_EXPPrefixBatchRemove(Operator):
    """Remove EXP_ prefix from all shape keys that have it"""
    bl_idname   = "panko.exp_prefix_batch_remove"
    bl_label    = "Remove All EXP_"
    bl_description = "Strip the EXP_ prefix from every shape key on the active mesh"
    bl_options  = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys

    def execute(self, context):
        obj = context.active_object
        count = 0
        for key in obj.data.shape_keys.key_blocks:
            if key.name.startswith("EXP_"):
                key.name = key.name[4:]
                count += 1
        self.report({'INFO'}, f"Removed EXP_ from {count} shape keys")
        return {'FINISHED'}


# ==============================================================================
#  UI PANEL — ANGELUS ARKIT HELPER  (tab: "ARKit H")
# ==============================================================================

class AK_UL_targets(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if item.obj:
            layout.label(text=item.obj.name, icon='MESH_DATA')


class AK_PT_panel(Panel):
    bl_label      = "ARKit Blendshape Helper"
    bl_idname     = "AK_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category   = "ARKit H"

    def draw(self, context):
        layout = self.layout
        scene  = context.scene
        master_obj = scene.ak_driver_mesh

        # — Mesh Setup ————————————————————————————
        m_box = layout.box()
        m_box.prop(
            scene, "ak_show_mesh_setup",
            icon='TRIA_DOWN' if scene.ak_show_mesh_setup else 'TRIA_RIGHT',
            text="Mesh Setup", emboss=False,
        )
        if scene.ak_show_mesh_setup:
            col = m_box.column(align=True)
            col.prop(scene, "ak_driver_mesh", text="Driver")
            row = col.row()
            row.template_list("AK_UL_targets", "", scene, "ak_targets", scene, "ak_target_index")
            btns = row.column(align=True)
            btns.operator("ak.target_add_selected", icon='ADD',    text="")
            btns.operator("ak.target_remove",       icon='REMOVE', text="")

            row = col.row(align=True)
            row.operator("ak.add_arkit_shapes", icon='SHAPEKEY_DATA',       text="Add ARKit")
            row.operator("ak.add_vrm_shapes",   icon='OUTLINER_OB_ARMATURE', text="Add VRM")
            row.operator("ak.delete_all_shapes", icon='ERROR',              text="")

        # — Global Controls ————————————————————————
        row = layout.row(align=True)
        row.operator("ak.create_drivers", icon='CONSTRAINT', text="Driver Link")
        row.operator("ak.remove_drivers", icon='CANCEL',     text="Driver Unlink")
        row = layout.row(align=True)
        row.operator("ak.select_all_meshes", icon='RESTRICT_SELECT_OFF', text="Select")
        row.operator("ak.select_basis",      icon='SHAPEKEY_DATA',       text="Basis")
        row.operator("ak.global_zero",       icon='FILE_REFRESH',        text="Zero All")

        if not master_obj or not master_obj.data.shape_keys:
            layout.label(text="Assign a Driver Mesh with shapes.", icon='INFO')
            return

        # — Blendshape Folders ————————————————————
        f_box  = layout.box()
        header = f_box.row()
        header.prop(
            scene, "ak_show_folders_setup",
            icon='TRIA_DOWN' if scene.ak_show_folders_setup else 'TRIA_RIGHT',
            text="Blendshape Folders", emboss=False,
        )
        header.row(align=True).operator("ak.autosort_shapes", icon='FILE_REFRESH', text="")

        if scene.ak_show_folders_setup:
            for group in scene.ak_groups:
                g_box  = f_box.box()
                header = g_box.row(align=True)
                header.prop(
                    group, "is_expanded",
                    icon='TRIA_DOWN' if group.is_expanded else 'TRIA_RIGHT',
                    text=group.name, emboss=False,
                )
                if group.is_expanded:
                    col = g_box.column(align=True)
                    for s_n in group.shapes_csv.split(","):
                        if not s_n:
                            continue
                        kb = master_obj.data.shape_keys.key_blocks.get(s_n)
                        if not kb:
                            continue
                        is_active = (
                            master_obj.active_shape_key_index
                            == master_obj.data.shape_keys.key_blocks.find(s_n)
                        )
                        row = col.row(align=True)
                        if s_n.endswith("Left"):
                            row.separator(factor=1.6)
                            row.label(icon='EVENT_L')
                        elif s_n.endswith("Right"):
                            row.separator(factor=1.6)
                            row.label(icon='EVENT_R')
                        else:
                            row.operator("ak.mirror_blendshape", text="", icon='MOD_MIRROR').shape_name = s_n
                        row.prop(kb, "value", text=s_n)
                        row.operator("ak.add_single_arkit_shape", text="", icon='ADD').shape_name = s_n
                        row.operator(
                            "ak.select_shape_key", text="",
                            icon='RESTRICT_SELECT_OFF' if is_active else 'RESTRICT_SELECT_ON',
                        ).shape_name = s_n
                        row.operator("ak.delete_single_shape", text="", icon='X').shape_name = s_n


# ==============================================================================
#  UI PANELS — HELPER SCRIPTS  (tab: "Helper Scripts")
# ==============================================================================

class PANKO_PT_VRMTools(Panel):
    bl_label      = "VRM Expression Tools"
    bl_idname     = "PANKO_PT_VRMTools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category   = "Helper Scripts"

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Create Blendshapes", icon='SHAPEKEY_DATA')
        box.operator("panko.create_arkit_blendshapes",     icon='ADD')
        box.operator("panko.create_arkit_vrm_blendshapes", icon='ADD')
        box.operator("panko.add_custom_blendshape",        icon='SOLO_ON')
        box.operator("panko.add_multiple_custom_blendshapes", icon='PRESET_NEW')

        box = layout.box()
        box.label(text="VRM Expression Setup", icon='ARMATURE_DATA')
        box.operator("panko.add_arkit_to_vrm",            icon='EXPORT')
        box.operator("panko.add_custom_blendshape_to_vrm", icon='PLUS')

        box = layout.box()
        box.label(text="Assign to VRM Proxies", icon='LINKED')
        box.operator("panko.assign_blendshapes_proxies",    icon='CONSTRAINT')
        box.operator("panko.assign_selected_mesh_proxies",  icon='MESH_DATA')


class PANKO_PT_MeshCleanup(Panel):
    bl_label      = "Mesh Cleanup"
    bl_idname     = "PANKO_PT_MeshCleanup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category   = "Helper Scripts"

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Blendshape Cleanup", icon='SHAPEKEY_DATA')
        box.operator("panko.remove_empty_blendshapes", icon='X')
        box.operator("panko.reset_blendshapes",        icon='LOOP_BACK')

        box = layout.box()
        box.label(text="Vertex Group Cleanup", icon='GROUP_VERTEX')
        box.operator("panko.remove_empty_vertex_groups",         icon='X')
        box.operator("panko.remove_unassigned_bone_vgroups",     icon='BONE_DATA')


class PANKO_PT_NamingTools(Panel):
    bl_label      = "Naming & Sorting"
    bl_idname     = "PANKO_PT_NamingTools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category   = "Helper Scripts"

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Shape Key Names", icon='SORTALPHA')
        box.operator("panko.rename_lr_suffix",              icon='ARROW_LEFTRIGHT')
        box.operator("panko.find_replace_shape_key_names",  icon='VIEWZOOM')
        box.operator("panko.sort_shape_keys_alpha",         icon='SORTALPHA')


class PANKO_PT_ExpressionPrefixer(Panel):
    bl_label      = "EXP_ Prefix Assigner"
    bl_idname     = "PANKO_PT_ExpressionPrefixer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category   = "Helper Scripts"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
            layout.label(text="Select a mesh with shape keys.", icon='INFO')
            return

        # Batch controls
        row = layout.row(align=True)
        row.operator("panko.exp_prefix_batch_add",    icon='ADD',    text="Tag All")
        row.operator("panko.exp_prefix_batch_remove", icon='REMOVE', text="Untag All")

        layout.separator(factor=0.5)

        # Per-shape toggle list
        col = layout.column(align=True)
        for key in obj.data.shape_keys.key_blocks:
            if key.name == "Basis":
                continue
            has_exp = key.name.startswith("EXP_")
            row = col.row(align=True)
            icon = 'PROP_ON' if has_exp else 'PROP_OFF'
            # Show clean display name; operator gets the actual key name
            display = key.name[4:] if has_exp else key.name
            op = row.operator("panko.toggle_exp_prefix", text=display, icon=icon, emboss=has_exp)
            op.shape_name = key.name


# ==============================================================================
#  REGISTER
# ==============================================================================

classes = [
    # Data models
    AK_GroupItem,
    AK_Target,
    # UI lists
    AK_UL_targets,
    # Angelus operators
    AK_OT_select_shape_key,
    AK_OT_add_arkit_shapes,
    AK_OT_add_vrm_shapes,
    AK_OT_autosort_shapes,
    AK_OT_mirror_blendshape,
    AK_OT_select_all_meshes,
    AK_OT_create_drivers,
    AK_OT_remove_drivers,
    AK_OT_select_basis,
    AK_OT_global_zero,
    AK_OT_delete_all_shapes,
    AK_OT_target_add_selected,
    AK_OT_target_remove,
    AK_OT_groups_toggle,
    AK_OT_delete_single_shape,
    AK_OT_add_single_arkit_shape,
    # VRM tool operators
    PANKO_OT_CreateARKitBlendshapes,
    PANKO_OT_CreateARKitVRMBlendshapes,
    PANKO_OT_AddARKitToVRMExpressions,
    PANKO_OT_AssignBlendshapesToProxies,
    PANKO_OT_AssignSelectedMeshBlendshapesToProxies,
    PANKO_OT_AddCustomBlendshape,
    PANKO_OT_AddMultipleCustomBlendshapes,
    PANKO_OT_AddCustomBlendshapeToVRM,
    # Mesh cleanup operators
    PANKO_OT_RemoveEmptyBlendshapes,
    PANKO_OT_RemoveEmptyVertexGroups,
    PANKO_OT_RemoveUnassignedBoneVertexGroups,
    # Naming & sorting operators
    PANKO_OT_RenameLRSuffix,
    PANKO_OT_SortShapeKeysAlpha,
    PANKO_OT_ResetBlendshapes,
    PANKO_OT_FindReplaceShapeKeyNames,
    # EXP_ prefix operators
    PANKO_OT_ToggleEXPPrefix,
    PANKO_OT_EXPPrefixBatchAdd,
    PANKO_OT_EXPPrefixBatchRemove,
    # Panels
    AK_PT_panel,
    PANKO_PT_VRMTools,
    PANKO_PT_MeshCleanup,
    PANKO_PT_NamingTools,
    PANKO_PT_ExpressionPrefixer,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    s = bpy.types.Scene
    s.ak_driver_mesh       = PointerProperty(type=bpy.types.Object, name="Driver")
    s.ak_targets           = CollectionProperty(type=AK_Target)
    s.ak_target_index      = IntProperty()
    s.ak_groups            = CollectionProperty(type=AK_GroupItem)
    s.ak_show_mesh_setup   = BoolProperty(default=True)
    s.ak_show_folders_setup = BoolProperty(default=True)


def unregister():
    s = bpy.types.Scene
    del s.ak_driver_mesh
    del s.ak_targets
    del s.ak_target_index
    del s.ak_groups
    del s.ak_show_mesh_setup
    del s.ak_show_folders_setup

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
